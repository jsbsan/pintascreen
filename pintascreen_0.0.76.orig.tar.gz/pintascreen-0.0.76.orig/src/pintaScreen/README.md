# superpintascreen

PintaScreen Plus: para gambas3.10 o superior, con mejoras en la toma de fonod de imagenes.